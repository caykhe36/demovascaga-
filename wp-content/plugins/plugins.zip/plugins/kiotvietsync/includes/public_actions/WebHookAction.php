<?php
/**
 * Created by PhpStorm.
 * User: tuyenvv
 * Date: 3/5/19
 * Time: 11:26 AM
 */

require_once KIOTVIET_PLUGIN_PATH . '/helpers/KiotvietWcProduct.php';

class WebHookAction extends KiotvietWcProduct
{
    protected $stockBranch, $regularPrice, $salePrice, $KiotvietWcCategory;
    private $wpdb, $retailer;

    public function __construct()
    {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->KiotvietWcCategory = new KiotvietWcCategory();
        $this->getConfig();
        $this->retailer = kiotviet_sync_get_data('retailer', "");
        parent::__construct();
    }

    public function register_api_route()
    {
        $webhookKey = get_option('webhook_key');

        register_rest_route('kiotviet-sync/v1/', $webhookKey . '/webhook/', array(
            'methods' => 'POST',
            'callback' => [$this, 'product'],
        ));
    }

    public function product()
    {
        $data = file_get_contents('php://input');
        file_put_contents('log_webhook_kiotviet.txt', $data);
        file_put_contents('log_webhook_kiotviet.txt', "\n\n\nThời gian: " . date("Y-m-d H:i:s", time()), FILE_APPEND);

        $response = [
            'code' => 0,
            'msg' => 'No action',
        ];

        if ($this->isJson($data)) {
            $data = json_decode($data);

            $action = $data->Notifications[0]->Action;

            list($entity, $method, $id) = explode('.', $action);

            if ($entity == 'stock' && $method == 'update') {
                $this->updateStock($data);
                $response = [
                    'code' => 1,
                    'msg' => 'Update stock',
                ];
            } elseif ($entity == 'product' && $method == 'update') {
                $this->updateProduct($data);
                $response = [
                    'code' => 1,
                    'msg' => 'Update product',
                ];
            } elseif ($entity == 'product' && $method == 'delete') {
                $this->deleteProduct($data);
                $response = [
                    'code' => 1,
                    'msg' => 'Delete product',
                ];
            } elseif ($entity == 'order' && $method == 'update') {
                $this->updateOrder($data);
                $response = [
                    'code' => 1,
                    'msg' => 'Update order',
                ];
            }
        }

        return $response;
    }

    protected function updateOrder($data)
    {
        $kvOrderId = $data->Notifications[0]->Data[0]->Id;
        $kvOrderStatus = $data->Notifications[0]->Data[0]->StatusValue;
        $kvOrderCode = $data->Notifications[0]->Data[0]->StatusValue;
        $orderId = $this->getOrderIdFromKvOrderId($kvOrderId);

        if ($orderId != -1) {
            $orderObj = wc_get_order($orderId);
            // handle status cancelled reduce stock
            if ($kvOrderStatus == "Đã hủy") {
                $update = [
                    'post_status' => 'wc-cancelled',
                ];
                $orderObj->add_order_note("Cập nhật từ KiotViet: <strong>{$kvOrderStatus}</strong>\n\n<hr />");
                $orderObj->save();
                $this->wpdb->update($this->wpdb->prefix . "posts", $update, array("ID" => $orderId));
            } else {
                $statusMappig = [
                    'Phiếu tạm' => 'processing',
                    'Đang xử lý' => 'processing',
                    'Hoàn thành' => 'completed',
                    'Đang giao hàng' => 'processing',
                ];
                $wcStatus = array_key_exists($kvOrderStatus, $statusMappig) ? $statusMappig[$kvOrderStatus] : '';
                $orderObj->set_status($wcStatus, "Cập nhật từ KiotViet: <strong>{$kvOrderStatus}</strong>\n\n<hr />");
                $orderObj->save();
            }

            kv_sync_log('KiotViet', 'Website', 'Cập nhật trạng thái đơn hàng thành công. Mã đơn hàng: #' . $kvOrderCode, json_encode($data), 1, $orderId);
        }

    }

    public function getOrderIdFromKvOrderId($kvOrderId)
    {
        global $wpdb;
        $order = $wpdb->get_row("SELECT * FROM `{$wpdb->prefix}kiotviet_sync_orders` WHERE `order_kv_id` = $kvOrderId", ARRAY_A);
        if (is_array($order)) {
            return $order['order_id'];
        }
        return -1;
    }

    protected function updateStock($data)
    {
        $inventories = $data->Notifications[0]->Data;

        foreach ($inventories as $inventory) {
            //  Todo: Will be check the branch in setting
            if ($inventory->BranchId == $this->stockBranch) {
                $wcProductAsync = $this->wpdb->get_row("SELECT `product_id` FROM {$this->wpdb->prefix}kiotviet_sync_products WHERE `product_kv_id` = " . $inventory->ProductId . " AND `retailer` = '" . $this->retailer . "'", ARRAY_A);
                if ($wcProductAsync) {
                    $wcProduct = wc_get_product($wcProductAsync['product_id']);
                    if ($wcProduct) {
                        $oldStock = $wcProduct->get_stock_quantity();
                        if ($oldStock != $inventory->OnHand) {
                            $wcProduct->set_stock_quantity($inventory->OnHand);
                            $wcProduct->save();
                            kv_sync_log('KiotViet', 'Website', 'Cập nhật thông tin tồn kho thành công. Mã sản phẩm: #' . $wcProductAsync['product_id'] . "\n Tồn kho " . $oldStock . " -> " . $inventory->OnHand, json_encode($data), 1, $wcProductAsync['product_id']);
                        }

                        // update stock parent when product variant
                        if ($wcProduct->get_type() == 'variation') {
                            $parentId = $wcProduct->get_parent_id();
                            $wcParentProduct = wc_get_product($parentId);
                            if($wcParentProduct){
                                $this->updateStockProductParent($wcParentProduct);
                            }
                        }
                    }

                }
            }
        }
    }

    protected function updateProduct($data)
    {
        try {
            $kvProducts = $data->Notifications[0]->Data;
            foreach ($kvProducts as $kvProduct) {
                $wcProductAsync = $this->wpdb->get_row("SELECT `product_id` FROM {$this->wpdb->prefix}kiotviet_sync_products WHERE `product_kv_id` = " . $kvProduct->Id . " AND `retailer` = '" . $this->retailer . "' AND `status` = 1", ARRAY_A);
                if ($wcProductAsync) {
                    $wcProductId = $wcProductAsync['product_id'];
                    $wcProduct = wc_get_product($wcProductId);

                    // get images
                    $images = $this->getImagesProduct($kvProduct->Images);
                    // remove - Website by Product name KV
                    $productName = preg_replace("/\s-\sWebsite$/", "", $kvProduct->Name);
                    // check parent Product
                    if ($kvProduct->HasVariants && !$kvProduct->MasterProductId) {
                        $parentId = $wcProduct->get_parent_id();
                        if ($parentId) {
                            $wcProductParent = wc_get_product($parentId);
                            $wcProductParent->set_name($productName);
                            $wcProductParent->set_description($kvProduct->Description);
                            $wcProductParent->set_weight($kvProduct->Weight);
                            $this->updateCategory($wcProductParent, $kvProduct->CategoryId);
                            if ($images) {
                                $this->set_image_data($wcProductParent, $images);
                            }
                            $this->updateLowStockProduct($wcProductParent, $kvProduct->Inventories);
                            $wcProductParent->save();
                        }
                    }

                    $wcProduct->set_name($productName);
                    $wcProduct->set_description($kvProduct->Description);
                    $wcProduct->set_weight($kvProduct->Weight);
                    $wcProduct->set_regular_price($kvProduct->BasePrice);

                    // update sku
                    if ($wcProduct->get_sku() !== $kvProduct->Code) {
                        // remove Website by sku Kv
                        $sku = preg_replace("/^Website/", "", $kvProduct->Code);
                        $wcProduct->set_sku($sku);
                    }

                    // product active false
                    if (!$kvProduct->isActive) {
                        $this->delete_product($wcProductId);
                        continue;
                    } else {
                        $wcProduct->set_status('publish');
                    }

                    //  Re-mapping the attribute to wordpress attribute
                    $attributes = [];
                    if ($kvProduct->Attributes) {
                        $attributes = $this->getAttributes($kvProduct->Attributes, $wcProduct);
                    }

                    if ($wcProduct->get_type() == 'variation') {
                        // Add new attribute in variant exits
                        $parentId = $wcProduct->get_parent_id();
                        $wcParentProduct = wc_get_product($parentId);
                        $this->check_attribute_parent($wcParentProduct, $attributes);
                        // update attributes
                        $this->set_variation_data($wcProduct, [
                            'raw_attributes' => $attributes,
                        ]);

                        // change parent product type variable to simple
                        if (!$kvProduct->HasVariants) {
                            $wcParentProduct->set_regular_price($kvProduct->BasePrice);
                            $this->updatePrice($wcParentProduct, $kvProduct->PriceBooks);
                            $wcParentProduct->save();
                            wp_set_object_terms($parentId, 'simple', 'product_type');
                        }
                    } else {
                        // update attribute
                        $this->set_product_data($wcProduct, [
                            'raw_attributes' => $attributes,
                        ]);

                        // update category
                        $this->updateCategory($wcProduct, $kvProduct->CategoryId);
                    }

                    //  Update images
                    if ($images) {
                        $this->set_image_data($wcProduct, $images);
                    }

                    //  Update stock
                    $this->updateStockProduct($wcProduct, $kvProduct->Inventories);

                    // Update low stock
                    $this->updateLowStockProduct($wcProduct, $kvProduct->Inventories);

                    // Update priceBook
                    $this->updatePrice($wcProduct, $kvProduct->PriceBooks);
                    $wcProduct->save();

                    // change type product simple to variant
                    if ($wcProduct->get_type() == "simple" && $kvProduct->HasVariants) {
                        wp_set_object_terms($wcProductId, 'variable', 'product_type');
                    }

                    if ($wcProduct->get_type() == "variable" && !$kvProduct->HasVariants) {
                        wp_set_object_terms($wcProductId, 'simple', 'product_type');
                    }

                    // update stock parent when product variant
                    if ($wcProduct->get_type() == 'variation') {
                        $wcParentProduct = wc_get_product($parentId);
                        $this->updateStockProductParent($wcParentProduct);
                    }

                    kv_sync_log('KiotViet', 'Website', 'Cập nhật thông tin sản phẩm thành công. Mã sản phẩm: #' . $kvProduct->Code, json_encode($data), 1, $wcProductId);
                } else {
                    // add product variant same type
                    if ($kvProduct->HasVariants && $kvProduct->MasterProductId && empty($kvProduct->MasterUnitId)) {
                        $wcProductSync = $this->wpdb->get_row("SELECT `product_id` FROM {$this->wpdb->prefix}kiotviet_sync_products WHERE `product_kv_id` = " . $kvProduct->MasterProductId . " AND `retailer` = '" . $this->retailer . "'", ARRAY_A);
                        // parent product is sync
                        if ($wcProductSync) {
                        $wcProduct = wc_get_product($wcProductSync['product_id']);
                            $parentId = $wcProduct->get_parent_id();
                            $wcParentProduct = wc_get_product($parentId);

                            $attributes = [];
                            if ($kvProduct->Attributes) {
                                $attributes = $this->getAttributes($kvProduct->Attributes, $wcProduct);
                            }

                            $this->check_attribute_parent($wcParentProduct, $attributes);
                            // update attributes
                            $product = $this->transformProduct($kvProduct, "variation", 0, $this->regularPrice, $this->salePrice, $this->stockBranch);
                            $product['parent_id'] = $parentId;
                            $this->import_product($product);
                            // update stock product parent
                            $this->updateStockProductParent($wcParentProduct);
                        }
                    }
                }
            }
        } catch (Exception $exception) {
            return $exception->getMessage();
        }
    }

    protected function deleteProduct($data)
    {
        $productIds = $data->Notifications[0]->Data;
        foreach ($productIds as $productId) {
            $wcProductAsync = $this->wpdb->get_row("SELECT `product_id` FROM {$this->wpdb->prefix}kiotviet_sync_products WHERE `product_kv_id` = " . $productId . " AND `retailer` = '" . $this->retailer . "'", ARRAY_A);
            if ($wcProductAsync) {
                $wcProductId = $wcProductAsync['product_id'];
                $this->delete_product($wcProductId, true);

                // delete product map sync
                $delete = [
                    "id" => $wcProductAsync['id'],
                ];

                $this->wpdb->delete($this->wpdb->prefix . "kiotviet_sync_products", $delete);
            }
        }
    }

    protected function isJson($string)
    {
        json_decode($string);
        return (json_last_error() == JSON_ERROR_NONE);
    }

    private function getConfig()
    {
        $branchStock = kiotviet_sync_get_data('config_branch_stock');
        $regularPrice = kiotviet_sync_get_data('regular_price');
        $salePrice = kiotviet_sync_get_data('sale_price');

        $branchStock = json_decode(html_entity_decode(stripslashes($branchStock)), true);
        if (is_array($branchStock) && array_key_exists('id', $branchStock)) {
            $this->stockBranch = $branchStock['id'];
        }

        $regularPrice = json_decode(html_entity_decode(stripslashes($regularPrice)), true);
        if (is_array($regularPrice) && array_key_exists('id', $regularPrice)) {
            $this->regularPrice = $regularPrice['id'];
        }

        $salePrice = json_decode(html_entity_decode(stripslashes($salePrice)), true);
        if (is_array($salePrice) && array_key_exists('id', $salePrice)) {
            $this->salePrice = $salePrice['id'];
        }
    }

    private function updateCategory(&$productObject, $categoryId)
    {
        $wcCategoryAsync = $this->wpdb->get_row("SELECT `category_id` FROM {$this->wpdb->prefix}kiotviet_sync_categories WHERE `retailer` = '" . $this->retailer . "' AND `category_kv_id` = " . $categoryId . "", ARRAY_A);
        if ($wcCategoryAsync) {
            $categoryId = $wcCategoryAsync['category_id'];
            $productObject->set_category_ids(array($wcCategoryAsync['category_id']));
        } else {
            $uncategorizedId = $this->KiotvietWcCategory->getUncategorizedId();
            $productObject->set_category_ids(array($uncategorizedId));
        }
    }

    private function getImagesProduct($images)
    {
        $data = [];
        if (!$images) {
            $data = [
                'raw_gallery_image_ids' => [],
                'raw_image_id' => [],
            ];
        } else {
            if (count($images) == 1) {
                $data = [
                    'raw_gallery_image_ids' => [],
                    'raw_image_id' => $images[0],
                ];
            } else if (count($images) > 1) {
                $raw_gallery_image_ids = [];
                foreach ($images as $key => $item) {
                    if ($key > 0) {
                        $raw_gallery_image_ids[] = $item;
                    }
                }

                $data = [
                    'raw_gallery_image_ids' => $raw_gallery_image_ids,
                    'raw_image_id' => $images[0],
                ];
            }
        }

        return $data;
    }

    private function updatePrice(&$product, $priceBooks)
    {
        if ($priceBooks) {
            foreach ($priceBooks as $priceBook) {
                if ($priceBook->PriceBookId == $this->regularPrice) {
                    $product->set_regular_price($priceBook->Price);
                }

                if ($priceBook->PriceBookId == $this->salePrice) {
                    $product->set_sale_price($priceBook->Price);
                    $product->set_date_on_sale_from(strtotime($priceBook->StartDate));
                    $product->set_date_on_sale_to(strtotime($priceBook->EndDate));
                }
            }
        }
    }

    private function updateStockProduct(&$wcProduct, $inventories)
    {
        foreach ($inventories as $inventory) {
            //  Todo: Will be check the branch in setting
            if ($inventory->BranchId == $this->stockBranch) {
                $wcProduct->set_stock_quantity($inventory->OnHand);
            }
        }
    }

    private function updateLowStockProduct(&$wcProduct, $inventories)
    {
        foreach ($inventories as $inventory) {
            //  Todo: Will be check the branch in setting
            if ($inventory->BranchId == $this->stockBranch) {
                $wcProduct->set_low_stock_amount($inventory->MinQuantity);
            }
        }
    }

    private function getAttributes($data, $wcProduct)
    {
        $attributes = [];
        $attributesTaxonomy = [];
        foreach ($data as $attribute) {
            $attributes[] = [
                'name' => $attribute->AttributeName,
                'value' => [
                    $attribute->AttributeValue,
                ],
                'visible' => true,
                'taxonomy' => false,
            ];
        }

        foreach ($wcProduct->get_attributes() as $attributeName => $attributeValue) {
            if (preg_match("/^pa_*/", $attributeName, $matches)) {
                $checkAttributeTaxonomy = true;
            }
        }

        if ($checkAttributeTaxonomy) {
            foreach ($attributes as $key => $attribute) {
                $attributesTaxonomy[] = [
                    'name' => "pa_" . strtolower($attribute['name']),
                    'value' => $attribute['value'],
                    'visible' => true,
                    'taxonomy' => true,
                ];
            }
            $attributes = $attributesTaxonomy;
        }

        return $attributes;
    }
}
